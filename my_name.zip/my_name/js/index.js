var sysF = 0;
var disF = 0;
var hrtF = 0;
var interval;
var message = prompt(" "+" "+" "+" "+" "+" "+" "+" "+" "+" "+" "+" "+"Write Your Name In The Field Below!");
alert("You're welcome "+message +", Tap on the scan button to measure your blood pressure, "+ message+" now!!");
var sysO = Math.floor(Math.random()*(210-100+1))+100;
var disO = Math.floor(Math.random()*(140-60+1))+60;
var hrtO = Math.floor(Math.random()*(110-55))+55;
function print() {
  stop();
  sysF+=3;
  disF+=2;
  hrtF+=1;
var vid = document.getElementById("myVideo");
vid.play();
  document.getElementById("sysF").innerHTML=sysF;
  document.getElementById("disF").innerHTML=disF;
  document.getElementById("hrtF").innerHTML=hrtF;
  interval = setInterval(print, 1000);
 
 if (sysF>=90){
  //alert("test1");
   document.getElementById("sysO").innerHTML=sysO;
   
   //stop();
 }
 if (disF>=60){
  //alert("test2");
   document.getElementById("disO").innerHTML=disO;
   //stop();
 }
 if(hrtF>=30){
  //alert("test3");
   document.getElementById("hrtO").innerHTML=hrtO;
   stop();
 }
}
function stop(){
  clearInterval(interval);
}
function showResult(){
   if(sysF==0 && disF==0 && hrtF ==0){
     document.getElementById("suggestions").innerHTML="Click on the scan button first then after you can click on suggestion button";
}
if (sysO <=50 && sysF==90 && disF==60 && hrtF==30){
  document.getElementById("suggestions").innerHTML="you are in danger look into your blood pressure your systolic is"+sysO+"your diastolic is"+disO+"and lastly your heart beat is"+hrtO+"call this number for suggestions 09037813514";
}
if (sysO <=100 && sysF==90 && disF==60 && hrtF==30){
  document.getElementById("suggestions").innerHTML="your blood is almost looking good but not at all look into the results your systolic is"+sysO+"your diastolic is"+disO+"and lastly your heart beat is"+hrtO+"call this number for suggestions 09037813514";
}


if (sysO<=150 && sysF==90 && disF==60 && hrtF==30){
  document.getElementById("suggestions").innerHTML="you are in critical condition look into your results your systolic is"+sysO+",your diastolic is"+disO+"and lastly your heart beat is"+hrtO+"Salisu Ali recommend you to keep exercise daily";
}

if (sysO<=200 && sysF==90 && disF==60 && hrtF==30){
  document.getElementById("suggestions").innerHTML="Am so sorry 😔 you are in danger look into your results your systolic is"+sysO+", your diastolic is"+disO+"and lastly your heart beat is"+hrtO+"Salisu Ali recommend you to call this number urgent for help 09037813514";
}


if (sysO>=201 && sysF==90 && disF==60 && hrtF==30){
  document.getElementById("suggestions").innerHTML="you are seriously 😒😥😥 in dangerous look into your results your systolic is"+sysO+", your diastolic is"+disO+"and lastly your heart beat is"+hrtO+"Salisu Ali Order you to call this number urgent 09037813514";
}



}
function dev() {
   alert("ABOUT DEVELOPER! SalisComputerist is the one who created this Site For Checking Blood Temperature! for more information you can be in touch with me via WhatsApp or true on this number 09037813514");
};